import express from 'express'
import cors from 'cors'
import { createServer } from 'http'

const app = express()
app.use(cors())
app.use(express.json())

// ── Config ──────────────────────────────────────────────────
const ODDS_API_KEY = process.env.ODDS_API_KEY || 'a24888a9fd0e4028a294dbaf9c5fb7cd'
const ODDS_BASE    = 'https://api.the-odds-api.com/v4'

const SPORT_KEYS = {
  NBA:   'basketball_nba',
  MLB:   'baseball_mlb',
  NHL:   'icehockey_nhl',
  NFL:   'americanfootball_nfl',
  UFC:   'mma_mixed_martial_arts',
  EPL:   'soccer_epl',
  NCAAB: 'basketball_ncaab',
}

// ── HSE MATH (server-side) ───────────────────────────────────
function computePressure(factors) {
  return Math.min(1, factors.reduce((s, f) => s + f.magnitude * f.weight, 0))
}
function oddsVariance(prices) {
  if (prices.length < 2) return 0.3
  return Math.min(1, (Math.max(...prices) - Math.min(...prices)) / 50)
}
function spreadMag(spread) {
  if (spread == null) return 0.4
  return Math.min(1, Math.abs(spread) / 20)
}
function vigPressure(homeOdds, awayOdds) {
  if (!homeOdds || !awayOdds) return 0.4
  const toProb = o => o > 0 ? 100 / (o + 100) : Math.abs(o) / (Math.abs(o) + 100)
  return Math.min(1, (toProb(homeOdds) + toProb(awayOdds) - 1) * 6)
}

function buildHSE(game) {
  const books = game.bookmakers || []
  const h2h     = books.flatMap(b => b.markets).find(m => m.key === 'h2h')
  const spreads = books.flatMap(b => b.markets).find(m => m.key === 'spreads')
  const totals  = books.flatMap(b => b.markets).find(m => m.key === 'totals')

  const homeOdds = h2h?.outcomes?.find(o => o.name === game.home_team)?.price
  const awayOdds = h2h?.outcomes?.find(o => o.name === game.away_team)?.price
  const spread   = spreads?.outcomes?.[0]?.point
  const total    = totals?.outcomes?.find(o => o.name === 'Over')?.point

  const allHomeOdds = books
    .map(b => b.markets.find(m => m.key === 'h2h')?.outcomes?.find(o => o.name === game.home_team)?.price)
    .filter(Boolean)

  const bookCount       = books.length
  const liquidityPressure = Math.max(0, 1 - bookCount / 12)

  const factors = [
    { name: 'Line Movement',   magnitude: oddsVariance(allHomeOdds),         weight: 0.25 },
    { name: 'Market Pressure', magnitude: vigPressure(homeOdds, awayOdds),   weight: 0.25 },
    { name: 'Spread Size',     magnitude: spreadMag(spread),                  weight: 0.20 },
    { name: 'Total Instability',magnitude: total ? Math.min(1, Math.abs(total - 220) / 100) : 0.3, weight: 0.15 },
    { name: 'Liquidity Gap',   magnitude: liquidityPressure,                  weight: 0.15 },
  ]
  const genome = [
    { label: 'Market Edge',    k: 1.2,  v: 0.8,  w: bookCount > 6 ? 0.9 : 0.7 },
    { label: 'Line Value',     k: 1.1,  v: spread  ? 0.85 : 0.6, w: 0.8 },
    { label: 'Price Stability',k: 0.95, v: allHomeOdds.length > 3 ? 0.8 : 0.6, w: 0.75 },
  ]

  const P       = computePressure(factors)
  const Eacc    = [P * 0.88, P * 0.94, P].reduce((s, v) => s + v, 0)
  const GEI     = genome.reduce((s, g) => s + g.k * g.v * g.w, 0)
  const Bcap    = 5.0
  const raw     = (GEI / (P + 0.001)) * (1 - Eacc / (Bcap + 0.001))
  const contain = Math.max(0, Math.min(1, raw))

  let signal
  if (Eacc > Bcap * 0.85)              signal = 'HOLD'
  else if (contain > 0.68 && P < 0.48) signal = 'BET'
  else if (contain > 0.52 && P < 0.62) signal = 'LEAN'
  else if (contain > 0.38)             signal = 'WATCH'
  else                                  signal = 'HOLD'

  let sharpPlay = 'HOLD'
  if (signal === 'BET' || signal === 'LEAN') {
    if (spread != null) {
      const fav = spread < 0 ? game.home_team : game.away_team
      sharpPlay = `${fav.split(' ').pop()} ${spread < 0 ? spread : '+' + Math.abs(spread)}`
    } else if (homeOdds) {
      sharpPlay = `${game.home_team.split(' ').pop()} ML ${homeOdds > 0 ? '+' : ''}${homeOdds}`
    }
  }

  return {
    game: `${game.away_team} vs ${game.home_team}`,
    time: new Date(game.commence_time).toLocaleTimeString('en-US', {
      hour: 'numeric', minute: '2-digit', timeZoneName: 'short'
    }),
    spread:     spread != null ? String(spread) : null,
    spreadTeam: spread != null ? (spread < 0 ? game.home_team : game.away_team) : null,
    total:      total  != null ? String(total)  : null,
    homeML:     homeOdds || null,
    awayML:     awayOdds || null,
    bookCount,
    factors,
    genome,
    P, Eacc, GEI, containment: contain,
    signal,
    sharpPlay,
    insight: `${bookCount} books reporting. Containment: ${(contain * 100).toFixed(0)}%, Pressure: ${(P * 100).toFixed(0)}%.`,
  }
}

// ── ROUTES ──────────────────────────────────────────────────
app.get('/api/odds/:sport', async (req, res) => {
  const { sport } = req.params
  const sportKey  = SPORT_KEYS[sport.toUpperCase()]
  if (!sportKey) return res.status(400).json({ error: 'Unknown sport' })

  try {
    const url = `${ODDS_BASE}/sports/${sportKey}/odds` +
      `?apiKey=${ODDS_API_KEY}` +
      `&regions=us` +
      `&markets=h2h,spreads,totals` +
      `&oddsFormat=american` +
      `&bookmakers=draftkings,fanduel,betmgm,caesars,pointsbet,betrivers`

    const response = await fetch(url)
    const remaining = response.headers.get('x-requests-remaining')

    if (!response.ok) {
      const text = await response.text()
      return res.status(response.status).json({ error: text })
    }

    const raw   = await response.json()
    const games = raw
      .sort((a, b) => new Date(a.commence_time) - new Date(b.commence_time))
      .map(buildHSE)

    res.json({ games, remaining, sport, timestamp: new Date().toISOString() })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

app.get('/api/sports', async (req, res) => {
  try {
    const url = `${ODDS_BASE}/sports?apiKey=${ODDS_API_KEY}`
    const response = await fetch(url)
    const data = await response.json()
    res.json(data)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

app.get('/api/health', (req, res) => {
  res.json({ status: 'HSE ENGINE NOMINAL', timestamp: new Date().toISOString() })
})

// Serve built frontend in production
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'
import { existsSync } from 'fs'
const __dirname = dirname(fileURLToPath(import.meta.url))
const distPath  = join(__dirname, '../dist')
if (existsSync(distPath)) {
  app.use(express.static(distPath))
  app.get('*', (req, res) => res.sendFile(join(distPath, 'index.html')))
}

const PORT = process.env.PORT || 3001
app.listen(PORT, () => console.log(`Guardian OS API running on :${PORT}`))
