# Guardian Betting OS
### Human Stability Engine™ — Patent Pending App. 19/633,827
### Guardian OS Holdings LLC

---

## Deploy to Vercel in 5 minutes

### Step 1 — Install tools (one time)
```bash
npm install -g vercel
```

### Step 2 — Set up project
```bash
npm install
cp .env.example .env
# Edit .env and paste your Odds API key
```

### Step 3 — Test locally
```bash
npm run dev
# Open http://localhost:5173
```

### Step 4 — Deploy to Vercel
```bash
vercel
# Follow prompts — choose defaults
# When asked about environment variables, add:
#   ODDS_API_KEY = your key here
```

### Step 5 — Set your Odds API key in Vercel dashboard
1. Go to vercel.com → your project → Settings → Environment Variables
2. Add: `ODDS_API_KEY` = `your key`
3. Redeploy

**Your live URL will be:** `https://guardian-betting-os.vercel.app`

---

## Tech Stack
- **Frontend:** React + Vite
- **Backend:** Express.js (Node)
- **Odds Data:** The Odds API (https://the-odds-api.com)
- **Hosting:** Vercel (free tier)
- **HSE Engine:** Patent App. 19/633,827

## Architecture
```
Browser → Vercel → Express API → The Odds API
                ↓
         HSE Math Engine
         P(t), E_acc, GEI,
         Containment Score,
         CFRL Signal
```

## Patent Notice
Guardian Betting OS is powered by the Human Stability Engine™.
Patent Pending — Application No. 19/633,827
© Guardian OS Holdings LLC. All rights reserved.
